# Logical dynamical axioms for exosys-rhiz

## Axiom A0 — Non-destructive precedence

No state transition that can destroy data is valid unless:

1. a human-set environment flag enables it,
2. preflight proves the selected target,
3. the transition writes a log record,
4. rollback notes are generated.

## Axiom A1 — Identity coherence

A host identity is the tuple:

```text
hostname + machine-id + SSH host key + LXD node name + iDRAC manager id
```

If two tuple members conflict, the node is in `identity_ambiguous` and cannot join the cluster.

## Axiom A2 — Namespace locality

Resources belong to one and only one primary namespace:

```text
hardware, host, vm, container, service, storage, memory, dump, auth, database
```

Cross-namespace links are references, not ownership changes.

## Axiom A3 — Memory-plane honesty

Host swap, guest swap, zram, coredump, and kdump are different memory planes.

A VM cannot safely use host swap as if it were guest swap. The host may swap QEMU pages, and the guest may swap inside itself, but those are coordinated pressure relief systems, not one shared RAM fabric.

## Axiom A4 — SSD pressure containment

SSD-backed swap and dumps are emergency buffers, not a substitute for enough DRAM.

When `swap_used / swap_total > 0.70` or `iowait > 30%`, orchestration must prefer throttling services over adding more swap pressure.

## Axiom A5 — MongoDB hub quorum

A MongoDB hub with three Docker members is valid only when:

```text
primary_count == 1
healthy_members >= 2
replica_set_name matches config
data paths live on intended SSD mount
```

## Axiom A6 — Remote handshake ladder

Remote trust is layered:

```text
iDRAC Redfish -> SSH host key -> OS machine-id -> LXD node identity -> service health -> auth/FIDO
```

Later layers do not repair contradictions in earlier layers.

## Axiom A7 — FIDO fail-open staging

FIDO/U2F config must be staged with `sufficient` semantics first. `required` is only allowed after at least one successful validation and a working root/session recovery channel.

## Axiom A8 — Observability before autonomy

The orchestrator may automate only states that have validation output. Unobservable transitions must remain manual.
