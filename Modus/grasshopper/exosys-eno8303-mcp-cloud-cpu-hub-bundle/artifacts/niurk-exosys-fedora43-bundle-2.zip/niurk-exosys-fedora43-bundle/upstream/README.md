# Upstream recovery bundle

This directory embeds the uploaded `niurk-ops-recovery.zip` so the exosys automation can be kept with the previous recovery material.

The orchestrator does not execute this archive automatically.
