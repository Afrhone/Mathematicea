# Memory, swap, and dump policy

## Goal

Use SSD as a resilient pressure/dump plane for the distributed architecture without pretending it is RAM.

## Implementation

- zram-generator creates compressed RAM swap.
- SSD swapfile gives host emergency swap.
- kdump stores crash dumps under SSD path.
- systemd-coredump stores userspace dumps under SSD path.
- VM swap script creates guest-local swapfiles inside selected LXD VMs.

## Guardrails

- Do not set MongoDB WiredTiger cache too high on a 16 GiB host.
- Do not run heavy AI model backends here unless more RAM is installed.
- Do not put production MongoDB data and high-churn swap on the same low-endurance SSD without monitoring.
- Prefer adding RAM to the R250. The platform can scale much higher than the current 16 GiB configuration.

## Recommended starting values for 16 GiB RAM

```text
zram max: 8G
host SSD swap: 32G-64G
VM swap: 4G-8G each
MongoDB cache: 1G-2G per container maximum
```
