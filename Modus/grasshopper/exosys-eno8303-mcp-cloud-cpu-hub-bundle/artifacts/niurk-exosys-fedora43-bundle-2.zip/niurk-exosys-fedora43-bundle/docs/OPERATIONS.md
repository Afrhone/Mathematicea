# Operations

## Full non-destructive report

```bash
./bin/niurk-exo-flow.sh plan
./bin/niurk-exo-flow.sh preflight
./bin/niurk-exo-flow.sh handshake
./bin/niurk-exo-flow.sh validate
```

## Enable execution

```bash
DRY_RUN=0 ./bin/niurk-exo-flow.sh host-baseline
DRY_RUN=0 ./bin/niurk-exo-flow.sh ssd-memory
DRY_RUN=0 ./bin/niurk-exo-flow.sh mongodb-hub
```

## Logs

```text
/var/log/niurk-exosys/
```

## State

```text
/var/lib/niurk-exosys/state/
```

## Rollback

```bash
DRY_RUN=0 ./bin/niurk-exo-flow.sh rollback
```

Rollback is conservative. It removes generated systemd configs and can stop the MongoDB compose stack, but it will not wipe SSD data unless you do it manually.
