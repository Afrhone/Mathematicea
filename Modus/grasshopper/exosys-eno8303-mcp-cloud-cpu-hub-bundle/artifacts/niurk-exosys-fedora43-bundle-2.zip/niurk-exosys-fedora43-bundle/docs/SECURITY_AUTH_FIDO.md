# Security, auth, and FIDO staging

## Principles

- iDRAC credentials are hardware-management credentials.
- OS user credentials are host credentials.
- FIDO/U2F keys bind users to host-login operations.
- MongoDB credentials bind services to database roles.
- Never store real secrets in this repo.

## FIDO staging

`FIDO_ENABLE=1` enables installation and config staging.

Default is fail-open:

```text
auth sufficient pam_u2f.so ...
```

Only after successful SSH, sudo, and console recovery tests should you consider:

```text
FIDO_REQUIRE_FOR_SUDO=1
FIDO_PAM_CONTROL=required
```

## Recovery

Keep at least one of the following before requiring FIDO:

- iDRAC virtual console access
- known-good root password
- local console
- rescue USB
- working SSH session with sudo
