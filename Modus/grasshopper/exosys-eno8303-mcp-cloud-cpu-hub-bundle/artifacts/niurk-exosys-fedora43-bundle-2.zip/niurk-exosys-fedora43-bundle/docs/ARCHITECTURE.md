# Architecture: exosys-rhiz

## Role

`exosys-rhiz` is a Dell PowerEdge R250 exosystem node.

Primary functions:

1. Fedora 43 server baseline.
2. LXD cluster candidate.
3. SSD-backed memory pressure/dump plane.
4. MongoDB Docker replica-set hub.
5. Remote handshake endpoint via iDRAC Redfish and SSH.
6. Namespace + identity validator for distributed rhiz services.

## Memory and dump plane

```text
RAM
 ├─ host processes
 ├─ LXD/QEMU processes
 └─ MongoDB/Docker containers

zram
 └─ first pressure relief, compressed RAM

SSD swap
 └─ host emergency swap for Fedora/LXD/QEMU processes

VM swap
 └─ guest-local swapfiles, created with lxc exec

SSD dumps
 ├─ /srv/exosys-ssd/dumps/kdump
 └─ /srv/exosys-ssd/dumps/coredump
```

## MongoDB hub

The bundle deploys three MongoDB containers:

```text
mongo1 -> 127.0.0.1:27017
mongo2 -> 127.0.0.1:27018
mongo3 -> 127.0.0.1:27019
replicaSet=rs_exosys
```

This is a local hub/replica-set for service integration. For true fault-domain resilience, place replica members on separate physical LXD nodes later.

## LXD integration

The LXD stage can:

- install LXD,
- stage node config,
- validate expected cluster endpoints,
- join only when `LXD_JOIN_TOKEN` is provided and `DRY_RUN=0`.

It does not invent a cluster token.
