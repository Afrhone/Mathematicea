# iDRAC Redfish handshake

Default endpoint:

```text
https://192.168.0.23/redfish/v1
```

The script `scripts/60-remote-handshake.sh` checks:

- Redfish service root
- system health summary
- manager/iDRAC presence
- event/log availability when credentials permit

It uses `curl` and prompts for the password if `IDRAC_PASSWORD` is empty.

No firmware update or power action is performed by default.
