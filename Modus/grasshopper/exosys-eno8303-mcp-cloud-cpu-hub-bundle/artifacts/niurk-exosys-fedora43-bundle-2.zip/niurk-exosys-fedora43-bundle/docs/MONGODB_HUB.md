# MongoDB hub

The hub is a local Docker Compose replica-set.

## Deploy

```bash
DRY_RUN=0 ./bin/niurk-exo-flow.sh mongodb-hub
```

## Validate

```bash
docker exec exo-mongo1 mongosh --quiet \
  -u "$MONGO_ROOT_USER" -p "$MONGO_ROOT_PASSWORD" \
  --authenticationDatabase admin \
  --eval 'rs.status()'
```

## Production note

A three-member replica set on one physical server is useful for local service semantics and failover testing, but not hardware fault tolerance. Later distribute members across `ark-rhiz`, `sigmo-rhiz`, and `exosys-rhiz`.
