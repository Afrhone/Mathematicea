#!/usr/bin/env bash
set -euo pipefail

NIURK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${ENV_FILE:-$NIURK_ROOT/config/exosys-rhiz.env}"
[[ -f "$ENV_FILE" ]] && source "$ENV_FILE" || source "$NIURK_ROOT/config/exosys-rhiz.env.example"

LOG_DIR="${LOG_DIR:-/var/log/niurk-exosys}"
STATE_DIR="${STATE_DIR:-/var/lib/niurk-exosys/state}"

mkdir -p "$LOG_DIR" "$STATE_DIR" 2>/dev/null || true

timestamp() { date -Is; }

log() {
  printf '[%s] %s\n' "$(timestamp)" "$*" | tee -a "$LOG_DIR/niurk-exosys.log" >&2
}

die() {
  log "FATAL: $*"
  exit 1
}

have() { command -v "$1" >/dev/null 2>&1; }

as_root_or_sudo() {
  if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
    "$@"
  else
    sudo "$@"
  fi
}

run() {
  log "+ $*"
  if [[ "${DRY_RUN:-1}" == "1" ]]; then
    return 0
  fi
  "$@"
}

run_bash() {
  local cmd="$1"
  log "+ bash -lc $cmd"
  if [[ "${DRY_RUN:-1}" == "1" ]]; then
    return 0
  fi
  bash -lc "$cmd"
}

run_root_bash() {
  local cmd="$1"
  log "+ root bash -lc $cmd"
  if [[ "${DRY_RUN:-1}" == "1" ]]; then
    return 0
  fi
  as_root_or_sudo bash -lc "$cmd"
}

mark_state() {
  local state="$1"
  printf '%s\n' "$(timestamp)" | as_root_or_sudo tee "$STATE_DIR/$state.ok" >/dev/null
}

require_cmd() {
  have "$1" || die "missing command: $1"
}

confirm_flag() {
  local flag_name="$1"
  local want="${2:-1}"
  local actual="${!flag_name:-}"
  [[ "$actual" == "$want" ]]
}

safe_source_env() {
  set -a
  [[ -f "$ENV_FILE" ]] && source "$ENV_FILE"
  set +a
}

print_env_summary() {
  cat <<EOF
ENV_FILE=$ENV_FILE
DRY_RUN=${DRY_RUN:-1}
HOST_FQDN=${HOST_FQDN:-}
HOST_ROLE=${HOST_ROLE:-}
IDRAC_IP=${IDRAC_IP:-}
SSD_DEVICE=${SSD_DEVICE:-}
SSD_MOUNT=${SSD_MOUNT:-}
LXD_INSTALL_MODE=${LXD_INSTALL_MODE:-}
MONGO_STACK_DIR=${MONGO_STACK_DIR:-}
VM_TARGETS=${VM_TARGETS:-}
EOF
}

detect_fedora_major() {
  if [[ -r /etc/fedora-release ]]; then
    grep -oE '[0-9]+' /etc/fedora-release | head -1
  elif [[ -r /etc/os-release ]]; then
    . /etc/os-release
    [[ "${ID:-}" == "fedora" ]] && echo "${VERSION_ID:-unknown}" || echo "not-fedora"
  else
    echo "unknown"
  fi
}

idrac_curl_base() {
  local insecure=()
  [[ "${IDRAC_TLS_VERIFY:-0}" == "0" ]] && insecure=(-k)
  local auth=()
  if [[ -n "${IDRAC_USER:-}" ]]; then
    if [[ -n "${IDRAC_PASSWORD:-}" ]]; then
      auth=(-u "${IDRAC_USER}:${IDRAC_PASSWORD}")
    else
      auth=(-u "${IDRAC_USER}")
    fi
  fi
  curl -fsS "${insecure[@]}" "${auth[@]}" "$@"
}
