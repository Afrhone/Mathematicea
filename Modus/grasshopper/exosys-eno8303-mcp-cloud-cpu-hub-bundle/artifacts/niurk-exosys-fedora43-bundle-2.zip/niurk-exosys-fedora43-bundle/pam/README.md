# PAM/FIDO staging

This directory intentionally contains documentation only.

Use:

```bash
FIDO_ENABLE=1 DRY_RUN=0 ./bin/niurk-exo-flow.sh fido-auth
```

Then enroll:

```bash
pamu2fcfg -u kobalt | sudo tee -a /etc/security/u2f_keys
```

Do not set FIDO as required until you have validated local console, iDRAC console, and an active recovery shell.
