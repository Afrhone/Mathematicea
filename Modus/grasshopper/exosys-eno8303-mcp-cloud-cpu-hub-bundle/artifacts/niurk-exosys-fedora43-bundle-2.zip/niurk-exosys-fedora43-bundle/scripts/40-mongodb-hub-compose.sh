#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

log "MongoDB hub deployment"

if [[ "${MONGO_ENABLE:-1}" != "1" ]]; then
  log "MONGO_ENABLE != 1, skipping"
  exit 0
fi

if [[ "${MONGO_ROOT_PASSWORD:-}" == "change-me-before-run" || "${MONGO_APP_PASSWORD:-}" == "change-me-before-run" ]]; then
  die "Change MONGO_ROOT_PASSWORD and MONGO_APP_PASSWORD in config before deploying MongoDB."
fi

if ! have docker; then
  log "Docker missing; installing Docker Engine from Fedora repository fallback."
  run_root_bash "dnf -y install docker docker-compose-plugin || dnf -y install moby-engine docker-compose-plugin"
  run_root_bash "systemctl enable --now docker"
fi

run_root_bash "mkdir -p '$MONGO_STACK_DIR' '$MONGO_DATA_DIR'/mongo{1,2,3}"
run_root_bash "chown -R 999:999 '$MONGO_DATA_DIR' || true"

tmp_env=/tmp/niurk-mongo.env
cat > "$tmp_env" <<EOF
MONGO_VERSION=${MONGO_VERSION:-7.0}
MONGO_REPLICA_SET=${MONGO_REPLICA_SET:-rs_exosys}
MONGO_BIND_IP=${MONGO_BIND_IP:-127.0.0.1}
MONGO_PORT_BASE=${MONGO_PORT_BASE:-27017}
MONGO_DATA_DIR=${MONGO_DATA_DIR:-/srv/exosys-ssd/mongodb-hub}
MONGO_ROOT_USER=${MONGO_ROOT_USER:-niurkRoot}
MONGO_ROOT_PASSWORD=${MONGO_ROOT_PASSWORD:-}
MONGO_APP_USER=${MONGO_APP_USER:-niurkApp}
MONGO_APP_PASSWORD=${MONGO_APP_PASSWORD:-}
MONGO_APP_DB=${MONGO_APP_DB:-niurk_hub}
EOF

run_root_bash "install -m 0600 '$tmp_env' '$MONGO_STACK_DIR/.env'"
run_root_bash "install -m 0644 '$ROOT/compose/mongodb-hub/compose.yaml' '$MONGO_STACK_DIR/compose.yaml'"

run_root_bash "cd '$MONGO_STACK_DIR' && docker compose --env-file .env up -d"

if [[ "${DRY_RUN:-1}" == "1" ]]; then
  log "Dry-run: not initializing replica set"
  mark_state mongodb-hub
  exit 0
fi

log "Waiting for MongoDB containers"
deadline=$((SECONDS + ${MONGO_INIT_TIMEOUT:-180}))
until docker exec exo-mongo1 mongosh --quiet --eval 'db.adminCommand({ ping: 1 }).ok' >/dev/null 2>&1; do
  [[ $SECONDS -gt $deadline ]] && die "mongo1 did not become ready"
  sleep 3
done

cat >/tmp/niurk-init-rs.js <<EOF
const rsName = "${MONGO_REPLICA_SET:-rs_exosys}";
try {
  rs.status();
  print("Replica set already initialized");
} catch(e) {
  rs.initiate({
    _id: rsName,
    members: [
      { _id: 0, host: "mongo1:27017" },
      { _id: 1, host: "mongo2:27017" },
      { _id: 2, host: "mongo3:27017" }
    ]
  });
}
EOF

docker cp /tmp/niurk-init-rs.js exo-mongo1:/tmp/niurk-init-rs.js
docker exec exo-mongo1 mongosh --quiet /tmp/niurk-init-rs.js || true

sleep 8

cat >/tmp/niurk-create-users.js <<EOF
db = db.getSiblingDB("admin");
if (!db.getUser("${MONGO_ROOT_USER:-niurkRoot}")) {
  db.createUser({
    user: "${MONGO_ROOT_USER:-niurkRoot}",
    pwd: "${MONGO_ROOT_PASSWORD}",
    roles: [ { role: "root", db: "admin" } ]
  });
}
db = db.getSiblingDB("${MONGO_APP_DB:-niurk_hub}");
if (!db.getUser("${MONGO_APP_USER:-niurkApp}")) {
  db.createUser({
    user: "${MONGO_APP_USER:-niurkApp}",
    pwd: "${MONGO_APP_PASSWORD}",
    roles: [ { role: "readWrite", db: "${MONGO_APP_DB:-niurk_hub}" } ]
  });
}
EOF

docker cp /tmp/niurk-create-users.js exo-mongo1:/tmp/niurk-create-users.js
docker exec exo-mongo1 mongosh --quiet /tmp/niurk-create-users.js || true

docker exec exo-mongo1 mongosh --quiet --eval 'rs.status().members.map(m => ({name:m.name,stateStr:m.stateStr,health:m.health}))'

mark_state mongodb-hub
log "MongoDB hub deployment complete"
