#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

log "Remote handshake start"

echo "== iDRAC =="
if [[ "${VALIDATE_IDRAC:-1}" == "1" ]]; then
  if timeout 5 bash -c ":</dev/tcp/${IDRAC_IP}/443" 2>/dev/null; then
    log "iDRAC port reachable"
    idrac_curl_base "${IDRAC_REDFISH_BASE:-https://$IDRAC_IP/redfish/v1}" | jq . 2>/dev/null || idrac_curl_base "${IDRAC_REDFISH_BASE:-https://$IDRAC_IP/redfish/v1}" || true
    echo
    idrac_curl_base "${IDRAC_REDFISH_BASE:-https://$IDRAC_IP/redfish/v1}/Systems/System.Embedded.1" | jq '{Id,Name,PowerState,Status,ProcessorSummary,MemorySummary}' 2>/dev/null || true
  else
    log "WARN: iDRAC not reachable"
  fi
fi

echo "== SSH peer handshakes =="
for host in ${SSH_HOSTS:-}; do
  log "SSH test $SSH_USER@$host"
  if [[ "${DRY_RUN:-1}" == "1" ]]; then
    log "+ ssh ${SSH_OPTS:-} ${SSH_USER:-kobalt}@$host 'hostname; cat /etc/machine-id'"
  else
    ssh ${SSH_OPTS:-} "${SSH_USER:-kobalt}@$host" 'hostname; cat /etc/machine-id' || log "WARN: SSH failed for $host"
  fi
done

echo "== LXD namespace =="
if have lxc; then
  lxc cluster list || true
  lxc list -c ns4tL || true
fi

echo "== Ontology validation =="
python3 - <<'PY' "$ROOT/ontology/identity-namespace.jsonld"
import json, sys
p=sys.argv[1]
data=json.load(open(p))
assert data["@id"] == "niurk:exosys-rhiz"
assert "niurk:namespace_rules" in data
print("ontology_ok", len(data["niurk:namespace_rules"]))
PY

mark_state handshake
log "Remote handshake complete"
