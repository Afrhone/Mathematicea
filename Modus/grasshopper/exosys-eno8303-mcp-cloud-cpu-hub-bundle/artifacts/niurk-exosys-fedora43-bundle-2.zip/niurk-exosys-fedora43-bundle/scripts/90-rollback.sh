#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

log "Rollback start"

cat <<EOF
Rollback policy:
- stops MongoDB compose stack if present
- removes niurk sysctl/zram/coredump snippets
- does not delete data
- does not wipe SSD
- does not remove Docker/LXD packages
- does not edit PAM
EOF

if [[ -f "${MONGO_STACK_DIR:-/srv/exosys-ssd/stacks/mongodb-hub}/compose.yaml" ]]; then
  run_root_bash "cd '$MONGO_STACK_DIR' && docker compose down || true"
fi

run_root_bash "rm -f /etc/sysctl.d/90-niurk-exosys.conf"
run_root_bash "rm -f /etc/systemd/zram-generator.conf"
run_root_bash "rm -f /etc/systemd/coredump.conf.d/90-niurk-exosys.conf"
run_root_bash "systemctl daemon-reload"
run_root_bash "sysctl --system || true"

log "Rollback complete. Data under ${SSD_MOUNT:-/srv/exosys-ssd} remains intact."
mark_state rollback
