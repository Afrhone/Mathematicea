#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

log "SSD memory/dump plane setup"

run_root_bash "mkdir -p '$SSD_MOUNT' '$SSD_MOUNT/swap' '$KDUMP_PATH' '$COREDUMP_PATH'"

if [[ -n "${SSD_DEVICE:-}" ]]; then
  if findmnt "$SSD_MOUNT" >/dev/null 2>&1; then
    log "$SSD_MOUNT already mounted"
  else
    if [[ "${ALLOW_FORMAT_SSD:-0}" == "1" ]]; then
      run_root_bash "mkfs.${SSD_FS:-xfs} -f '$SSD_DEVICE'"
      uuid="$(blkid -s UUID -o value "$SSD_DEVICE" 2>/dev/null || true)"
      if [[ -n "$uuid" ]]; then
        line="UUID=$uuid $SSD_MOUNT ${SSD_FS:-xfs} defaults,noatime 0 2"
      else
        line="$SSD_DEVICE $SSD_MOUNT ${SSD_FS:-xfs} defaults,noatime 0 2"
      fi
      echo "$line" >/tmp/niurk-fstab-line
      run_root_bash "grep -q ' $SSD_MOUNT ' /etc/fstab || cat /tmp/niurk-fstab-line >> /etc/fstab"
      run_root_bash "mount '$SSD_MOUNT'"
    else
      log "SSD_DEVICE set but not mounted. ALLOW_FORMAT_SSD=0, not formatting."
      log "Mount it manually or set ALLOW_FORMAT_SSD=1 after confirming the device."
    fi
  fi
fi

# zram-generator config
if [[ "${ZRAM_ENABLE:-1}" == "1" ]]; then
  cat >/tmp/zram-generator.conf <<EOF
[zram0]
zram-size = min(ram * ${ZRAM_FRACTION:-0.50}, ${ZRAM_MAX:-8G})
compression-algorithm = zstd
swap-priority = 100
EOF
  run_root_bash "install -D -m 0644 /tmp/zram-generator.conf /etc/systemd/zram-generator.conf"
  run_root_bash "systemctl daemon-reload"
  run_root_bash "systemctl restart systemd-zram-setup@zram0.service || true"
fi

# SSD swapfile
if [[ -n "${HOST_SWAPFILE:-}" ]]; then
  if [[ "${DRY_RUN:-1}" == "1" ]]; then
    log "+ create swapfile $HOST_SWAPFILE size $HOST_SWAP_SIZE"
  else
    as_root_or_sudo mkdir -p "$(dirname "$HOST_SWAPFILE")"
    if [[ ! -f "$HOST_SWAPFILE" ]]; then
      as_root_or_sudo fallocate -l "${HOST_SWAP_SIZE:-64G}" "$HOST_SWAPFILE" || as_root_or_sudo dd if=/dev/zero of="$HOST_SWAPFILE" bs=1M count="$((64*1024))" status=progress
      as_root_or_sudo chmod 0600 "$HOST_SWAPFILE"
      as_root_or_sudo mkswap "$HOST_SWAPFILE"
    fi
    grep -qF "$HOST_SWAPFILE" /etc/fstab || echo "$HOST_SWAPFILE none swap defaults,pri=${HOST_SWAP_PRIORITY:-20} 0 0" | as_root_or_sudo tee -a /etc/fstab >/dev/null
    as_root_or_sudo swapon "$HOST_SWAPFILE" || true
  fi
fi

# kdump config
if [[ "${KDUMP_ENABLE:-1}" == "1" ]]; then
  run_root_bash "sed -i.bak.niurk '/^path /d' /etc/kdump.conf 2>/dev/null || true"
  run_root_bash "grep -q '^path $KDUMP_PATH' /etc/kdump.conf 2>/dev/null || echo 'path $KDUMP_PATH' >> /etc/kdump.conf"
  run_root_bash "systemctl enable kdump.service || true"
fi

# systemd-coredump
cat >/tmp/niurk-coredump.conf <<EOF
[Coredump]
Storage=external
Compress=yes
ProcessSizeMax=8G
ExternalSizeMax=8G
MaxUse=${SYSTEMD_COREDUMP_MAX_USE:-12G}
KeepFree=4G
EOF
run_root_bash "install -D -m 0644 /tmp/niurk-coredump.conf /etc/systemd/coredump.conf.d/90-niurk-exosys.conf"
run_root_bash "mkdir -p '$COREDUMP_PATH'"
run_root_bash "mkdir -p /var/lib/systemd/coredump"
run_root_bash "if [[ ! -L /var/lib/systemd/coredump/niurk-exosys ]]; then ln -sfn '$COREDUMP_PATH' /var/lib/systemd/coredump/niurk-exosys; fi"

echo "== swap =="
swapon --show || true
free -h || true

mark_state ssd-memory
log "SSD memory/dump plane setup complete"
