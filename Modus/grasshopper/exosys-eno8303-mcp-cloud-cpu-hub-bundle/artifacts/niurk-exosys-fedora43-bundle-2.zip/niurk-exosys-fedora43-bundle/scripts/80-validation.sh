#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

report="/tmp/niurk-exosys-validation-$(date +%Y%m%d-%H%M%S).txt"

{
echo "# niurk exosys-rhiz validation"
date -Is
echo

echo "== env =="
print_env_summary
echo

echo "== host =="
hostnamectl || true
cat /etc/os-release || true
echo

echo "== memory =="
free -h || true
swapon --show || true
zramctl || true
echo

echo "== dumps =="
findmnt "$SSD_MOUNT" || true
ls -lah "$KDUMP_PATH" "$COREDUMP_PATH" 2>/dev/null || true
systemctl status kdump --no-pager 2>/dev/null || true
echo

echo "== disks =="
df -hT || true
lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,MODEL,SERIAL || true
echo

echo "== docker =="
docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}' 2>/dev/null || true
docker compose -f "$MONGO_STACK_DIR/compose.yaml" ps 2>/dev/null || true
echo

echo "== mongodb =="
docker exec exo-mongo1 mongosh --quiet --eval 'rs.status().members.map(m => ({name:m.name,stateStr:m.stateStr,health:m.health}))' 2>/dev/null || true
echo

echo "== lxd =="
lxc cluster list 2>/dev/null || true
lxc list -c ns4tL 2>/dev/null || true
echo

echo "== idrac =="
if timeout 5 bash -c ":</dev/tcp/${IDRAC_IP}/443" 2>/dev/null; then
  echo "idrac_reachable=true"
else
  echo "idrac_reachable=false"
fi
echo

echo "== failed units =="
systemctl --failed --no-pager || true
} | tee "$report"

log "Validation report: $report"
mark_state validate
