#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

log "LXD node setup"

case "${LXD_INSTALL_MODE:-snap}" in
  none)
    log "LXD_INSTALL_MODE=none, validating only"
    ;;
  snap)
    if ! have snap; then
      run_root_bash "dnf -y install snapd"
      run_root_bash "systemctl enable --now snapd.socket"
      run_root_bash "ln -sfn /var/lib/snapd/snap /snap"
    fi
    if ! have lxc; then
      run_root_bash "snap install lxd --channel=${LXD_SNAP_CHANNEL:-5.21/stable}"
      run_root_bash "usermod -aG lxd '${ADMIN_USER:-kobalt}' || true"
    fi
    ;;
  package)
    run_root_bash "dnf -y install lxd lxc || true"
    ;;
  *)
    die "Unknown LXD_INSTALL_MODE=${LXD_INSTALL_MODE}"
    ;;
esac

if have lxc; then
  lxc version || true
  lxc cluster list || true
else
  log "WARN: lxc command still missing"
fi

cat > /tmp/exosys-lxd-preseed.yaml <<EOF
config:
  core.https_address: ${LXD_CLUSTER_ADDR:-0.0.0.0}:${LXD_CLUSTER_PORT:-8444}
networks: []
storage_pools:
- name: ${LXD_STORAGE_POOL:-exosys-ssd}
  driver: dir
  config:
    source: ${SSD_MOUNT:-/srv/exosys-ssd}/lxd-storage
profiles:
- name: default
  config: {}
  devices:
    root:
      path: /
      pool: ${LXD_STORAGE_POOL:-exosys-ssd}
      type: disk
cluster:
  server_name: ${HOST_SHORT:-exosys-rhiz}
  enabled: true
EOF

run_root_bash "install -D -m 0644 /tmp/exosys-lxd-preseed.yaml /var/lib/niurk-exosys/exosys-lxd-preseed.yaml"

if [[ -n "${LXD_JOIN_TOKEN:-}" ]]; then
  log "LXD_JOIN_TOKEN is set; join can be performed when DRY_RUN=0"
  cat <<EOF
Manual join pattern:
  lxc cluster join-token ${HOST_SHORT:-exosys-rhiz}
  lxd init --preseed < /var/lib/niurk-exosys/exosys-lxd-preseed.yaml
EOF
else
  log "No LXD_JOIN_TOKEN set. Not joining cluster."
fi

for pair in ${LXD_CLUSTER_NODES:-}; do
  name="${pair%%:*}"
  ip="${pair##*:}"
  if timeout 3 bash -c ":</dev/tcp/$ip/8444" 2>/dev/null; then
    log "LXD endpoint reachable: $name $ip:8444"
  else
    log "WARN: LXD endpoint not reachable: $name $ip:8444"
  fi
done

mark_state lxd-node
log "LXD node setup complete"
