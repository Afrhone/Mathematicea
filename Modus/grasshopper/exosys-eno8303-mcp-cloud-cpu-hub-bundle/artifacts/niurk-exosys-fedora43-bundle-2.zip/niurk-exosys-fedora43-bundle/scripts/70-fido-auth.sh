#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

log "FIDO auth staging"

if [[ "${FIDO_ENABLE:-0}" != "1" ]]; then
  log "FIDO_ENABLE != 1, skipping"
  exit 0
fi

run_root_bash "dnf -y install pam-u2f pamu2fcfg"

cat >/tmp/niurk-pam-u2f-line <<EOF
auth ${FIDO_PAM_CONTROL:-sufficient} pam_u2f.so authfile=${FIDO_AUTHFILE:-/etc/security/u2f_keys} origin=${FIDO_ORIGIN:-pam://exosys-rhiz} appid=${FIDO_APPID:-pam://exosys-rhiz} cue
EOF

run_root_bash "install -D -m 0644 /tmp/niurk-pam-u2f-line /etc/security/niurk-pam-u2f-line"

cat <<EOF
FIDO staging prepared.

To enroll for user:
  pamu2fcfg -u ${ADMIN_USER:-kobalt} | sudo tee -a ${FIDO_AUTHFILE:-/etc/security/u2f_keys}

To activate manually, insert this line cautiously into the relevant PAM stack:
  $(cat /tmp/niurk-pam-u2f-line)

This script intentionally does not edit /etc/pam.d/system-auth automatically.
EOF

if [[ "${FIDO_REQUIRE_FOR_SUDO:-0}" == "1" ]]; then
  log "FIDO_REQUIRE_FOR_SUDO=1 requested; still not auto-editing PAM. Use manual console after enrollment."
fi

mark_state fido-auth
