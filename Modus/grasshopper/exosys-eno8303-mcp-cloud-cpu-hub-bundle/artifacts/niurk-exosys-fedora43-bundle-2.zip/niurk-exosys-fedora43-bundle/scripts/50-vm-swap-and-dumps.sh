#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

log "VM swap and dump coordination"

if [[ "${VM_SWAP_ENABLE:-1}" != "1" ]]; then
  log "VM_SWAP_ENABLE != 1, skipping"
  exit 0
fi

require_cmd lxc

for vm in ${VM_TARGETS:-}; do
  log "Processing VM: $vm"
  if ! lxc info "$vm" >/dev/null 2>&1; then
    log "WARN: VM not found or inaccessible: $vm"
    continue
  fi
  state="$(lxc info "$vm" | awk '/^Status:/ {print $2}')"
  if [[ "$state" != "Running" ]]; then
    log "WARN: VM not running: $vm state=$state"
    continue
  fi

  guest_cmd=$(cat <<EOF
set -euo pipefail
mkdir -p /swap /var/lib/niurk-dumps
if ! swapon --show=NAME | grep -q '^/swap/niurk-vm.swap$'; then
  if [[ ! -f /swap/niurk-vm.swap ]]; then
    fallocate -l '${VM_SWAP_SIZE:-8G}' /swap/niurk-vm.swap || dd if=/dev/zero of=/swap/niurk-vm.swap bs=1M count=8192 status=progress
    chmod 0600 /swap/niurk-vm.swap
    mkswap /swap/niurk-vm.swap
  fi
  grep -q '/swap/niurk-vm.swap' /etc/fstab || echo '/swap/niurk-vm.swap none swap defaults,pri=${VM_SWAP_PRIORITY:-10} 0 0' >> /etc/fstab
  swapon /swap/niurk-vm.swap || true
fi
cat >/etc/sysctl.d/90-niurk-vm-memory.conf <<SYS
vm.swappiness = 35
vm.vfs_cache_pressure = 90
vm.dirty_background_ratio = 5
vm.dirty_ratio = 15
SYS
sysctl --system >/dev/null || true
free -h
swapon --show
EOF
)
  if [[ "${DRY_RUN:-1}" == "1" ]]; then
    log "+ lxc exec $vm -- bash -lc '$guest_cmd'"
  else
    lxc exec "$vm" -- bash -lc "$guest_cmd"
  fi
done

mark_state vm-swap
log "VM swap and dump coordination complete"
