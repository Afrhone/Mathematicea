#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

log "Preflight start"
print_env_summary

echo "== OS =="
cat /etc/os-release || true
fedora_major="$(detect_fedora_major)"
echo "Detected Fedora major: $fedora_major"
if [[ "$fedora_major" != "${FEDORA_TARGET_MAJOR:-43}" ]]; then
  log "WARN: target Fedora major is ${FEDORA_TARGET_MAJOR:-43}, detected $fedora_major"
fi

echo "== Host identity =="
hostnamectl || true
cat /etc/machine-id 2>/dev/null || true
ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub 2>/dev/null || true

echo "== CPU / RAM =="
lscpu | sed -n '1,40p' || true
free -h || true
grep -E 'MemTotal|SwapTotal|SwapFree' /proc/meminfo || true

echo "== Disks =="
lsblk -o NAME,TYPE,SIZE,FSTYPE,MOUNTPOINTS,MODEL,SERIAL || true
findmnt "$SSD_MOUNT" || true
if [[ -n "${SSD_DEVICE:-}" ]]; then
  lsblk "$SSD_DEVICE" || die "SSD_DEVICE not found: $SSD_DEVICE"
else
  log "WARN: SSD_DEVICE is unset. Set it before enabling formatting or swap."
fi

echo "== Network =="
ip -br addr || true
ip route || true

echo "== iDRAC Redfish probe =="
if [[ "${VALIDATE_IDRAC:-1}" == "1" ]]; then
  if timeout 5 bash -c ":</dev/tcp/${IDRAC_IP}/443" 2>/dev/null; then
    log "iDRAC 443 reachable at $IDRAC_IP"
    idrac_curl_base "${IDRAC_REDFISH_BASE:-https://$IDRAC_IP/redfish/v1}" | head -c 1000 || true
    echo
  else
    log "WARN: iDRAC 443 not reachable at $IDRAC_IP"
  fi
fi

echo "== LXD =="
if have lxc; then
  lxc version || true
  lxc cluster list || true
else
  log "lxc command not installed yet"
fi

echo "== Docker =="
if have docker; then
  docker version || true
  docker compose version || true
else
  log "docker not installed yet"
fi

echo "== Kernel memory tooling =="
sysctl vm.swappiness vm.overcommit_memory kernel.core_pattern 2>/dev/null || true
systemctl status kdump --no-pager 2>/dev/null || true

mark_state preflight
log "Preflight complete"
