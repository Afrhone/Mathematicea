#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

log "Fedora host baseline"

fedora_major="$(detect_fedora_major)"
if [[ "$fedora_major" != "${FEDORA_TARGET_MAJOR:-43}" ]]; then
  log "WARN: Fedora major mismatch detected=$fedora_major target=${FEDORA_TARGET_MAJOR:-43}"
fi

if [[ "${INSTALL_RUNTIME_PACKAGES:-1}" == "1" ]]; then
  run_root_bash "dnf -y install curl jq git rsync tar unzip htop iotop sysstat lsof bind-utils nc openssh-clients openssh-server policycoreutils-python-utils firewalld chrony tuned cockpit kexec-tools systemd-zram-generator podman podman-compose"
fi

if [[ "${DOCKER_ENABLE:-1}" == "1" ]]; then
  cat <<'EOF'
Docker Engine is installed by 40-mongodb-hub-compose.sh using Docker's repo path if docker is missing.
Fedora podman remains available for rootless validation.
EOF
fi

if [[ "${ENABLE_CHRONY:-1}" == "1" ]]; then
  run_root_bash "systemctl enable --now chronyd"
fi

if [[ "${ENABLE_FIREWALLD:-1}" == "1" ]]; then
  run_root_bash "systemctl enable --now firewalld"
  run_root_bash "firewall-cmd --permanent --add-service=ssh || true"
  run_root_bash "firewall-cmd --permanent --add-service=cockpit || true"
  run_root_bash "firewall-cmd --reload || true"
fi

if [[ "${ENABLE_COCKPIT:-1}" == "1" ]]; then
  run_root_bash "systemctl enable --now cockpit.socket"
fi

run_root_bash "systemctl enable --now sshd || true"

cat >/tmp/90-niurk-exosys.conf <<EOF
vm.swappiness = 25
vm.vfs_cache_pressure = 80
vm.dirty_background_ratio = 5
vm.dirty_ratio = 15
kernel.sysrq = 1
EOF
run_root_bash "install -m 0644 /tmp/90-niurk-exosys.conf /etc/sysctl.d/90-niurk-exosys.conf && sysctl --system"

if have tuned-adm; then
  run_root_bash "tuned-adm profile ${TUNED_PROFILE:-virtual-host} || true"
fi

mark_state host-baseline
log "Fedora host baseline complete"
