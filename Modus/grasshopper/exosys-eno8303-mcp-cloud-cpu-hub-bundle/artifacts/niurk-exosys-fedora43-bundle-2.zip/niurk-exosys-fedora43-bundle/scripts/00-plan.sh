#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT/lib/niurk-common.sh"

log "Rendering plan"
print_env_summary

cat <<EOF

Planned stages:

1. preflight
   - inspect Fedora version, hostname, memory, CPU, disks
   - probe iDRAC Redfish at ${IDRAC_IP:-unset}
   - inspect LXD and Docker if installed

2. host-baseline
   - install/enable packages and services
   - chrony, firewalld, cockpit, tuned, sysstat, jq, curl
   - no service disruption expected

3. ssd-memory
   - create ${SSD_MOUNT:-/srv/exosys-ssd}
   - optionally format ${SSD_DEVICE:-unset} only if ALLOW_FORMAT_SSD=1
   - create ${HOST_SWAPFILE:-unset}
   - configure zram-generator
   - configure kdump/systemd-coredump paths

4. lxd-node
   - install or validate LXD
   - stage exosys-rhiz as candidate cluster node
   - join only if LXD_JOIN_TOKEN is set

5. mongodb-hub
   - deploy 3 MongoDB containers on SSD
   - initialize replica set ${MONGO_REPLICA_SET:-rs_exosys}

6. vm-swap
   - for each VM in ${VM_TARGETS:-unset}, create guest-local swapfile
   - optional dump mount staging only if enabled

7. handshake
   - Redfish, SSH, LXD, namespace checks

8. fido-auth
   - disabled unless FIDO_ENABLE=1

9. validate
   - generate report

DRY_RUN=${DRY_RUN:-1}
EOF

mark_state plan
