# niurk exosys-rhiz Fedora 43 automation bundle

Generated: 2026-04-30T22:45:45Z

Purpose: bootstrap and validate **exosys-rhiz** on a Dell PowerEdge R250 as a safe, dry-run-first exosystem node for the rhiz distributed architecture.

This bundle is designed around:

- Fedora 43 Server baseline hardening and runtime packages.
- LXD cluster readiness and remote handshakes.
- SSD-backed host swap, zram, crash/core dump directories, and VM-local swap coordination.
- MongoDB replica-set hub across Docker containers.
- Remote config handshake through SSH and Dell iDRAC Redfish at `192.168.0.23`.
- FIDO/U2F system-auth staging without locking you out by default.
- Namespace / identity coherence across host, VM, container, service, port, database, dump, and ontology types.
- A small state-machine orchestrator with validation gates and rollback hooks.

## Safety defaults

The orchestrator defaults to `DRY_RUN=1`. It will print commands without executing destructive operations.

The bundle **does not** repartition, format, stop services, reset iDRAC, join LXD, modify PAM, or enable swap until you explicitly set the matching environment flags.

## Quick start

```bash
unzip niurk-exosys-fedora43-bundle.zip
cd niurk-exosys-fedora43-bundle

cp config/exosys-rhiz.env.example config/exosys-rhiz.env
nano config/exosys-rhiz.env

# inspect only
./bin/niurk-exo-flow.sh plan
./bin/niurk-exo-flow.sh preflight

# execute selected stages
DRY_RUN=0 ./bin/niurk-exo-flow.sh host-baseline
DRY_RUN=0 ./bin/niurk-exo-flow.sh ssd-memory
DRY_RUN=0 ./bin/niurk-exo-flow.sh mongodb-hub
DRY_RUN=0 ./bin/niurk-exo-flow.sh validate
```

## Important memory model

Host and VM memory cannot literally become one shared swap space. The safe architecture is:

1. Host zram for fast compressed memory pressure relief.
2. SSD-backed host swap for the Fedora/LXD/QEMU host.
3. VM-local swapfiles for guest pressure.
4. Host-side crash/core dump directories on SSD.
5. Optional virtiofs/disk mount into VMs for dump export, not live RAM sharing.
6. LXD memory limits and priority tuning to keep guest pressure bounded.

This bundle implements that coordinated model.

## Directory map

```text
bin/                 state-machine entrypoint
lib/                 common shell helpers
scripts/             stage scripts
config/              env templates and host/VM topology
state/               state-machine definitions
compose/             Docker Compose stacks
systemd/             optional systemd units/timers
pam/                 staged FIDO/PAM snippets
ontology/            identity + namespace coherence model
docs/                architecture and operations documentation
upstream/            optional uploaded recovery bundle, if present at generation time
```

## Minimal host target

```text
HOST_FQDN=exosys-rhiz
ROLE=exosystem
IDRAC_IP=192.168.0.23
PLATFORM=Dell PowerEdge R250
OS_TARGET=Fedora 43 Server
CPU=Intel Xeon E-2314
RAM_CURRENT=16GiB
SSD_ROLE=swap + crashdump + MongoDB volume + LXD storage candidate
```
