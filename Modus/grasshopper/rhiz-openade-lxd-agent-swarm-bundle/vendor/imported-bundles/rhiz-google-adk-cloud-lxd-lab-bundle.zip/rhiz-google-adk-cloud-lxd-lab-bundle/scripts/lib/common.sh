#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
ENV_FILE="${ENV_FILE:-$ROOT_DIR/env/rhiz-adk-lab.env}"
if [ -f "$ENV_FILE" ]; then set -a; source "$ENV_FILE"; set +a; fi
log(){ printf '\n[%s] %s\n' "$(date +%H:%M:%S)" "$*"; }
warn(){ printf '\n[WARN] %s\n' "$*" >&2; }
fail(){ printf '\n[ERR] %s\n' "$*" >&2; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || fail "missing command: $1"; }
confirm(){
  local msg="${1:-Continue?}"
  if [ "${RHIZ_ASSUME_YES:-0}" = "1" ]; then return 0; fi
  read -r -p "$msg [y/N] " ans
  case "$ans" in y|Y|yes|YES) return 0;; *) fail "aborted";; esac
}
lxc_cmd(){ if [ "${LXD_REMOTE:-local}" = "local" ]; then lxc "$@"; else lxc "${LXD_REMOTE}:" "$@"; fi; }
