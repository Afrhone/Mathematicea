module.exports = { output: 'standalone' }
